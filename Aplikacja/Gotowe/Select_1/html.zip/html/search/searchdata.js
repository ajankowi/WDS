var indexSectionsWithContent =
{
  0: "_dhikmnoprsuvwxz",
  1: "mpvw",
  2: "dhikmnoprsuvwz",
  3: "_px"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Funkcje",
  3: "Zmienne"
};

