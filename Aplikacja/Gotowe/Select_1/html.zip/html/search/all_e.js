var searchData=
[
  ['x_0',['x',['../class_punkt.html#a3c8936f679ef8fc4c1380ebc45820dc4',1,'Punkt']]]
];
