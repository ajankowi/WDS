var searchData=
[
  ['poloz_0',['Poloz',['../class_watek_poloz.html#ad5d9c05b490c240b110d2e4ea5dd444f',1,'WatekPoloz']]],
  ['postselection_1',['postSelection',['../class_viewer.html#aed885858645c43559de13e29ec0735a5',1,'Viewer']]]
];
