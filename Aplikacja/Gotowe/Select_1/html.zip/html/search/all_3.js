var searchData=
[
  ['init_0',['init',['../class_particle.html#af0fa0db02a3ff8013d1e17887ada9f5e',1,'Particle::init()'],['../class_viewer.html#a255cc2d6f55fc8565e614618d41589b1',1,'Viewer::init()']]]
];
