var searchData=
[
  ['koniec_0',['Koniec',['../class_watek_com.html#ab67c0a917471619a242f3f5c60e2a0e3',1,'WatekCom']]]
];
