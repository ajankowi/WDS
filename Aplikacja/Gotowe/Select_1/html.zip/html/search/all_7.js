var searchData=
[
  ['onkoniec_0',['onKoniec',['../class_main_window.html#aea3978e3854f6c852a90d2c980d6b6dd',1,'MainWindow']]],
  ['onnumberch_1',['onNumberCh',['../class_main_window.html#ae6c977219220157db8e2bb91efa738a3',1,'MainWindow']]],
  ['onpoloz_2',['onPoloz',['../class_main_window.html#a9d6922c5fd038bbe7846cd1839d154c7',1,'MainWindow']]],
  ['onstatus_3',['onStatus',['../class_main_window.html#adff55ad5842eddb12afddf0058e72d5b',1,'MainWindow']]],
  ['onwspolrz_4',['onWspolrz',['../class_viewer.html#ac995b4f8aa3bc69e28eda9b20231aa7d',1,'Viewer']]]
];
