var searchData=
[
  ['zakoncz_0',['zakoncz',['../class_watek_odbioru.html#a7c73f21a97b5684869e9fb3ef1dfbe3d',1,'WatekOdbioru']]],
  ['zmien_1',['zmien',['../class_watek_com.html#ad36ce2e50aa728a55baabf8831d690c4',1,'WatekCom::zmien()'],['../class_watek_odbioru.html#a303f1b0f7776229a8fba9c3ec36e7e73',1,'WatekOdbioru::zmien()']]]
];
