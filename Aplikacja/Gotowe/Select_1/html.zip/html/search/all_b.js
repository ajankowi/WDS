var searchData=
[
  ['ustawpoloz_0',['ustawPoloz',['../class_punkt.html#abdaff2cd92e390536c055f409f24a3fd',1,'Punkt']]]
];
